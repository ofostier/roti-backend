// this file is copied somewhere else so this lint rule is incorrect
module.exports =
  // eslint-disable-next-line import/no-extraneous-dependencies
  require('@keystone-next/keystone/___internal-do-not-use-will-break-in-patch/admin-ui/next-config').config;
