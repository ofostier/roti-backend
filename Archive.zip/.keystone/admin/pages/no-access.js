import { getNoAccessPage } from '@keystone-next/keystone/___internal-do-not-use-will-break-in-patch/admin-ui/pages/NoAccessPage';

export default getNoAccessPage({ sessionsEnabled: true });
