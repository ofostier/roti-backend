export { HomePage as default } from '@keystone-next/keystone/___internal-do-not-use-will-break-in-patch/admin-ui/pages/HomePage';
